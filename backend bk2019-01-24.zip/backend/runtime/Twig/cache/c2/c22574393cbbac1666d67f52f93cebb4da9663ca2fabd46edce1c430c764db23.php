<?php

/* render.twig */
class __TwigTemplate_7b50fb92f083fba94e0991b7fde588180691adbbce520acf109ad5a8d8d1f663 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h1 class=\"header-test\">This is twig</h1>

";
        // line 3
        $context["greeting"] = "Hello ";
        // line 4
        $context["name"] = "Fabien";
        // line 5
        echo "
";
        // line 6
        echo twig_escape_filter($this->env, ($context["name"] ?? null), "html", null, true);
        echo " 

";
        // line 8
        echo twig_escape_filter($this->env, ($context["username"] ?? null), "html", null, true);
        echo "

";
        // line 10
        echo twig_escape_filter($this->env, ($context["link"] ?? null), "html", null, true);
    }

    public function getTemplateName()
    {
        return "render.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 10,  35 => 8,  30 => 6,  27 => 5,  25 => 4,  23 => 3,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "render.twig", "/Applications/MAMP/htdocs/deposite/backend/views/dashboard/render.twig");
    }
}
