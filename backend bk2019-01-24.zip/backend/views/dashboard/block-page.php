<?php
    use yii\helpers\Html;
    use yii\helpers\ArrayHelper;
    use yii\widgets\ActiveForm;
    use backend\models\ProductType;
    $this->title = 'Change password';
    $this->params['breadcrumbs'][] = $this->title;

//$this->registerJsFile(Yii::getAlias('@web').'/js/jquery.dataTables.min.js',['depends' => 'yii\web\JqueryAsset']);
//$this->registerJsFile(Yii::getAlias('@web').'/js/invoice-create.js',['depends' => 'yii\web\JqueryAsset']);
//$this->registerCssFile(Yii::getAlias('@web').'/css/jqueryDataTables.css');
//$this->registerCssFile(Yii::getAlias('@web').'/css/invoice-create.css');
//$this->registerJsFile(Yii::getAlias('@web').'/js/jquery-ui.js',['depends' => 'yii\web\JqueryAsset']);
//$this->registerCssFile(Yii::getAlias('@web').'/css/jquery-ui.css');
?>

<div class="warning"><h3> <?= $content ?> </h3></div>