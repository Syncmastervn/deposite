<?php
    use yii\helpers\Html;
    use yii\widgets\ActiveForm;
    $this->title = 'Close Invoice';
    $this->params['breadcrumbs'][] = $this->title;
?>


<center>
    <h1>Hoàn thành đóng hoá đơn</h1>
</center>