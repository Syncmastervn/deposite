<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \common\models\LoginForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

$this->title = 'Search Failed';
$this->params['breadcrumbs'][] = $this->title;
?>


<div class="site-search-invoice-failed">
    <center>
        <h2>Failed</h2>
    </center>
</div>