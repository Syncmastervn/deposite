<?php
    use yii\helpers\Html;
    use yii\widgets\ActiveForm;
    $this->title = 'Login';
    $this->params['breadcrumbs'][] = $this->title;
?>

<h1>Login success</h1>
Xin chào <b><?= $username ?></b> 
<br>
Bạn đã đăng nhập thành công