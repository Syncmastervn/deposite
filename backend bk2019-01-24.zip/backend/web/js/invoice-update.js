$(document).ready(function(){
    $('.lock').replaceWith("<div>"+$('.lock').val()+"</div>");
});